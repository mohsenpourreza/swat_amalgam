%%% Initiate a matlabenpool of 8 processors.
Size_labpools = 8;
matlabpool open local 8;
%%% Iterations begins.
No_iter=1;
while (No_iter < Max_no_iter)
    %%% Sample parameter sets using AMALGAM.
    Size_population=96;% Define the size of population of a generation
    x=AMALGAM(Size_population,obj_values);% The function �AMALGAM� represents the AMALGAM algorithm that samples parameter sets.
    %%% Divide sampled parameter sets to 8 groups.
    x_group(No_labpools)= divide(x,Size_labpools);% �No_labpool� is an index for indicating each lab, and it can
    %have a value from 1 to Size_labpools; the �divide� function
    %evenly splits a set of parameter sets sampled in the previous
    %step into 8 (�Size_labpools�) groups.
    %%% Change parameter values in parallel.
    % Eight (�Size_labpools�) sets of SWAT input files should
    %be located under individual sub-directories (i.e. �lab1�,
    %�lab2�, and �lab8�) so that each sub-directory will have a set
    %of SWAT inputfiles.
    spmd% Parallel computing using �spmd� begins here.
        bsn(x_group(No_labpool));% Basin level parameters (i.e. SURLAG, TIMP, etc.).
        sub(x_group(No_labpool));% Subbasin level  parameters (i.e. CH_NI, CH_SI, etc.).
        hru(x_group(No_labpool));% HRU level parameters (i.e. ESCO, OV_N, etc.).
        mgt(x_group(No_labpool));% Management parameters (i.e. CN2, etc.).
        sol(x_group(No_labpool));% Soil parameters (i.e. SOL_AWC, SOL_Z, etc.).
        gw(x_group(No_labpool));% Groundwater parameters (i.e. ALPHA_BF, GWQMN, etc.).
        rte(x_group(No_labpool));% Routing parameters (i.e. CH_NII, CH_SII, etc.).
    end% Parallel computing using �spmd� ends here.
    %%% Once parameter values are updated in the previous step, run SWAT with sampled parameter sets, read
    %modeling outputs, and write outputs of interest in parallel.
    spmd% Parallel computing using �spmd� begins here.
        system('rev488_32rel.exe', No_labpool);% Run SWAT (can also use the �!� or �dos� commands for
        %the Windows operating system).
        outputs=read_output('output.rch', No_labpool);% Read modeling outputs.
        write_output(outputs,'streamflow.txt', No_labpool);% Extract and write outputs of interest into a text file (i.e. �streamflow.txt�).
    end% Parallel computing using �spmd� ends here.
    %%% Once SWAT is run with sampled parameter values, and outputs of interest are extracted, calculate the objective
    %function values (or performance statistics) in parallel.
    spmd% Parallel computing using �spmd� begins here.
        outputs_interest=read_output('streamflow.txt', No_labpool);%Read modeling outputs of interest
        %from the text file (�streamflow.txt�).
        obj_values_group(No_labpool)=calculate_obj(outputs_interest, observed, No_labpool);% calculate objective function values.
    end% Parallel computing using �spmd� ends here.
    %%% Once all the parallel computing parts are completed, collect objective functions values calculated in the 8 labs.
    obj_values=combine_obj(obj_values_group, No_labpool);
    %%% Finalize a cycle of sampling and evaluation by updating the number of iterations.
    No_iter=No_iter+1;
end;% The iterations (�while (No_iter < Max_no_iter)�) ends.
%%% Close the matlabpool.
matlabpool close;