library(hydroPSO)
library(hydroTSM)
library(hydroGOF)
library(lhs)

model.drty <- getwd()
obs.fname <- paste(model.drty,"/obs.txt",sep="",collapse = NULL)
x <- read.zoo(obs.fname)

sim.fname <- paste(model.drty,"/best_sim_4obj.txt",sep="",collapse = NULL)
#sim.fname <- paste(model.drty,"/best_sim_trmse.txt",sep="",collapse = NULL)

y <- read.zoo(sim.fname)


# data.frame with the 2 time series
xx <- data.frame(observed=x, simulated=y)

# FDC plot
fdc(xx, lQ.thr=0.67, hQ.thr=0.33,log="x", thr.shw=TRUE)
