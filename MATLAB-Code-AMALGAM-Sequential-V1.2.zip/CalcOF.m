function OF = CalcOF(ModPred,Measurement,~)
% Calculate the objective functions 
%% Calculate the RMSE
%OF(1) = sqrt(sum((ModPred - Measurement.MeasData).^2)/Measurement.N);
%% Calculate NS

OF(1) = -(1-(sum((ModPred - Measurement.MeasData).^2)/sum((Measurement.MeasData-mean(Measurement.MeasData)).^2)));
%% Calculate the trmse 
Qtrs=(((1+ModPred).^0.3)-1)/0.3;
Qtro=(((1+Measurement.MeasData).^0.3)-1)/0.3;

OF(2) = sqrt((1/length(ModPred)).*sum((Qtrs - Qtro).^2));

%% Calculate the ROCE 
OF(3)= abs(sum(Measurement.MeasData) - sum(ModPred))/sum(Measurement.MeasData); %relative ROCE measure
    
%% Calculate the SFDCE 

OF(4)= abs(((prctile(ModPred',67)-prctile(ModPred',33))/(prctile(Measurement.MeasData',67)-prctile(Measurement.MeasData,33)))-1)*100;
