function [newof,newcg,simrr] = CompOF(x,AMALGAMPar,Measurement,ModelName,Extra)
% This function computes the objective function for each x value
global Size_labpools
initial=zeros(AMALGAMPar.N/Size_labpools,Measurement.N);
simrr=zeros(AMALGAMPar.N/Size_labpools,Measurement.N);
initialof=zeros(AMALGAMPar.N/Size_labpools,AMALGAMPar.nobj);
newof=zeros(AMALGAMPar.N/Size_labpools,AMALGAMPar.nobj);
% Evaluate each parameter combination and compute the objective functions
%x_group(No_labpools)= divide(x,Size_labpools);% �No_labpool� is an index for indicating each lab, and it can
[r,c] = size(x);
nlay  = Size_labpools;
x = permute(reshape(x',[c,r/nlay,nlay]),[2,1,3]);

for ii = 1:AMALGAMPar.N/Size_labpools,
    % Call model to generate simulated data
    %evalstr = ['ModPred = ',ModelName,'(x(ii,:),rem(ii,Size_labpools)+1);']; %eval(evalstr);
    spmd
        iRan=rem(ii,Size_labpools)+1;
        iRan=labindex;
        
        path_dir='../James_maury_mon.Sufi2.SwatCup';
        ext='/model.in';
        num=int2str(iRan);%transforms a number into a word
        
        model_in=strcat(path_dir,num,ext);
        
        %global Par;
        fid = fopen(model_in,'r');
        c = textscan(fid,'%s%f');
        fclose(fid);
        c{1,2}=x(ii,:,iRan)';
        fid = fopen(model_in,'w+');
        for nn=1 :size(x(ii,:,:),2)
            
           fprintf(fid,'%s     %f\n',c{1,1}{nn,1},c{1,2}(nn,1));
            
        end
        fclose(fid);
        
        path_dir='../James_maury_mon.Sufi2.SwatCup';
        
        FLOW_OUT=strcat(path_dir,num,'\SUFI2.OUT/FLOW_OUT_13.txt');
        
        if exist(FLOW_OUT) > 0
            delete(FLOW_OUT);
        end
        run_dir= strcat(path_dir,num,'/');
        cd (run_dir)
        dos run.bat;
        %cd ../lord.Sufi2.SwatCup/SUFI2.OUT/
        fid = fopen(FLOW_OUT,'r');
        
        fgets(fid);
        c = textscan(fid,'%f %f');
        fclose(fid);
        ModPred =c{1,2};
        cd ../MATLAB-Code-AMALGAM-Sequential-V1.2/
        
    
    % Calculate the objective functions by comparing model predictions with
    OF = CalcOF(ModPred,Measurement,Extra);
    SIMRR(ii,:)=ModPred';
    % Store the objective function values for each point
    newOF(ii,1:AMALGAMPar.nobj) = OF;
    
    % Define the contstraint violation
    newCg(ii,1) = 0;
    end;
    
end

for i=1 :Size_labpools
initial= [initial;SIMRR(1,i)];
initialof=[initialof;newOF(1,i)];
end

for i=1 :Size_labpools+1
simrr= [simrr;initial{i,1}];
newof= [newof;initialof{i,1}];
end
%simrr=simrr(2*AMALGAMPar.N/Size_labpools+1:end,:);
newof=newof(2*AMALGAMPar.N/Size_labpools+1:end,:);
newcg=zeros(size(newof,1),1);
simrr=simrr(2*AMALGAMPar.N/Size_labpools+1:end,:);
