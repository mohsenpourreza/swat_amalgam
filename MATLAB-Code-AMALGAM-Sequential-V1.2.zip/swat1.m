function [SimRR] = swat1(Pars,iRan)
spmd
path_dir='../James_maury_mon.Sufi2.SwatCup';
ext='/model.in';
num=int2str(iRan);%transforms a number into a word

model_in=strcat(path_dir,num,ext);

%global Par;
fid = fopen(model_in,'r');
c = textscan(fid,'%s%f');
fclose(fid);
c{1,2}=Pars';
fid = fopen(model_in,'w+');
for ii=1 :size(Pars,2)
    
    fprintf(fid,'%s     %f\n',c{1,1}{ii,1},c{1,2}(ii,1));
    
end
fclose(fid);

path_dir='../James_maury_mon.Sufi2.SwatCup';

FLOW_OUT=strcat(path_dir,num,'\SUFI2.OUT/FLOW_OUT_13.txt');

if exist(FLOW_OUT) > 0
    delete(FLOW_OUT);
end
run_dir= strcat(path_dir,num,'/');
cd (run_dir)
dos run.bat;
%cd ../lord.Sufi2.SwatCup/SUFI2.OUT/
fid = fopen(FLOW_OUT,'r');

temp = fgets(fid);
c = textscan(fid,'%f %f');
fclose(fid);
SimRR =c{1,2};
cd ../MATLAB-Code-AMALGAM-Sequential-V1.2/
% x = (Pars);
% file_id = id_func(n_sub);
% par_alter(Extra.par_n,Extra.par_f,x);
% % !./sw2009nancy
% ! swat477win.exe
% iVars = [1];
% rchproc(iVars,n_sub,outlet);
% for oidx = 1:length(outlet)
%     simdata_t = textread(['sim_daily' num2str(outlet(oidx)) '.dat'],'','headerlines',1);
%     simdata(:,oidx) = simdata_t(:,end);
% end
%
% SimRR = simdata;
end