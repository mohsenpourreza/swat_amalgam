%%% Initiate a matlabpool of 8 processors.
Size_labpools = 8;
matlabpool open local 8;
%%% Iterations begins.
No_iter=1;
while (No_iter < Max_no_iter)
    %%% Sample parameter sets using AMALGAM.
    % Each parameter set sampled here represent a spatial distribution of crop areas and the corresponding
    %management practices.
    Size_population=96;% Define the size of population of a generation.
    x=AMALGAM(Size_population,obj_values);% The function �AMALGAM� represents the AMALGAM
    %algorithm that samples parameter sets.
    %%% Change parameter values, run SWAT with sampled parameter sets, read modeling outputs, and write outputs of
    %interest, calculate the objective function values (or performance statistics) in parallel.
    % The parallel computing method of using �parfor� for the
    %spatial optimization will automatically create the number (�Size_population�) of working directories for running
    %SWAT with input files.
    parfor iRun=1:Size_population% Parallel computing using        parfor %� begins here.
        obs_values=run_SWAT(x,iRun)% This parallel computing method does not require an index for a �lab�.
    end% Parallel computing using �parfor� ends here.
    %%% Finalize a cycle of sampling and evaluation by updating the number of iterations.
    No_iter=No_iter+1;.
end;% The iterations (�while (No_iter < Max_no_iter)�) ends.
%%% Close the matlabpool.
matlabpool close;
%%% �run_SWAT� function.
function [obs_values]=run_SWAT(x,iRun)% The beginning of the �run_SWAT� function.
mkdir(['/simulation/sim' num2str(iRun)]);% Make a directory for a SWAT run.
copyfile('/originalSWAT/*.*,['/simulation/sim' num2str(iRun)]); %Copy a set of SWAT input files into
%a directory created in the previous step. distribute_crop_management(iRun);% Change values in
the SWAT input files (�.hru�) to reflect changes in the
distributions of crop and the corresponding management
practices (according to a parameter set sampled).
system('rev488_32rel.exe');% Run SWAT (can also use the �!� or �dos� commands for the Windows operating system).
outputs=read_output(�output.hru�,iRun);% Read modeling outputs.
write_output(outputs,�simHRU.txt�,iRun);% Extract and write outputs of interest into a text file (i.e. �simHRU.txt�).
obs_values=calculate_obs(iRun,�simHRU.txt�);
%Calculate objective function values.
end% The end of the �run_SWAT� function  .