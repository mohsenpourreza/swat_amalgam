clear all;
clc;
%for matlab parallel
matlabpool close force local
matlabpool open 4

global Par Size_labpools
Size_labpools=4; % matlabpool('size');

Extra.Alg = {'GA','PSO','AMS','DE'};

% Define the number of algorithms
AMALGAMPar.q = size(Extra.Alg,2);



fid = fopen('../James_maury_mon.Sufi2.SwatCup1\SUFI2.IN/par_inf.txt','r');
temp = fgets(fid);
if size(findstr(temp,'Number'),1)>0
    AMALGAMPar.n = str2num(strtok(temp));                       % Dimension of the problem
end
c = textscan(fid,'%s%f%f','headerLines',1);
fclose(fid);

AMALGAMPar.N = 64;                     % Size of the population, note: should be selected as multiplire of Size_labpools
AMALGAMPar.nobj = 4;                    % Number of objectives
AMALGAMPar.ndraw = 6400;               % Maximum number of function evaluations

% Define the parameter ranges (minimum and maximum values)
ParRange.minn = c{1,2}(1:AMALGAMPar.n,:); ParRange.maxn = c{1,3}(1:AMALGAMPar.n,:);ParRange.par=c{1,1}(1:AMALGAMPar.n,:);
ParRange.minn = ParRange.minn'; ParRange.maxn = ParRange.maxn';
Par=ParRange.par;
% How is the initial sample created -- Latin Hypercube sampling
Extra.InitPopulation = 'LHS';

% Load the Leaf River data
fid = fopen('../James_maury_mon.Sufi2.SwatCup1\SUFI2.IN/observed_rch.txt','r');
temp = fgets(fid);
c = textscan(fid,'%f%s%f','headerLines',5);
fclose(fid);

% Define the measured streamflow data
Measurement.MeasData = c{1,3}; Measurement.Sigma = []; Measurement.N = size(Measurement.MeasData,1);
Measurement.seq=c{1,1};

% Define ModelName
ModelName = 'swat1';
%ModelName(2,:) = 'swat2';

% Define the boundary handling
Extra.BoundHandling = 'Bound';

% True Pareto front is not available -- real world problem
Fpareto = [];


% Store example number in structure Extra
Extra.m = AMALGAMPar.n;

% Run the AMALGAM code and obtain non-dominated solution set
[output,ParGen,ObjVals,ParSet,SIMRR] = AMALGAM(AMALGAMPar,ModelName,ParRange,Measurement,Extra,Fpareto);
save amalgam.mat
matlabpool close;